package com.mycompany.mavenproject1;

import java.util.Scanner;

public class Mavenproject1 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Aluno aluno = new Aluno();

        System.out.print("Digite a primeira nota: ");
        aluno.setNota1(scanner.nextDouble());

        System.out.print("Digite a segunda nota: ");
        aluno.setNota2(scanner.nextDouble());

        System.out.print("Digite a terceira nota: ");
        aluno.setNota3(scanner.nextDouble());

        double media = aluno.calcularMedia();

        System.out.println("Média do bimestre: " + media);

        if (media >= 7) {
            System.out.println("Aluno aprovado!");
        } else {
            System.out.println("Aluno reprovado!");
        }

        scanner.close();
    }
}