package main;
public class CarculadoraMuitoFoda 
{
    public static void main(String[] args) 
    {
        
    }
}
