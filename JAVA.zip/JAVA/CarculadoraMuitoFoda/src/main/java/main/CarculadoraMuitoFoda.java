package main;
public class CarculadoraMuitoFoda 
{
    
    public static void digitarnumero()
    {
        
     }        
        
    public static void main(String[] args) 
    {
        
    }
}
