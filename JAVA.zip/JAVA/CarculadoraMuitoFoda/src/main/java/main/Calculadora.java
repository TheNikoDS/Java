package main;
public class Calculadora 
{
    private double primeiroNumero;   
    private double segundoNumero;  
    private String operacao;
    //Construtor padrão
    
    public Calculadora()
    {
        limpar();
    }        
    
    //Reseta o estado da calculadora
    public void limpar()
    {
        this.primeiroNumero = 0;
        this.segundoNumero = 0;
        this.operacao = "";        
    }        
    
    //Prepara a calculadora para receber o segundo numero
    public void prepararOperacao(double numero, String operacao)
    {
        this.primeiroNumero = numero;
        this.operacao = operacao;
    }        
    
    //Realiza o calculo baseado no operador armazenado
    public double calcular(double segundoNumero)
    {
        this.segundoNumero = segundoNumero;
        double resultado = 0;
        
        switch(this.operacao)
        {
            
            case "+":
                resultado = primeiroNumero + segundoNumero;
                break;
            case "-":
                resultado = primeiroNumero - segundoNumero;
                break;    
            case "*":
                resultado = primeiroNumero * segundoNumero;
                break;    
            case "/":
                if(segundoNumero == 0)
                {
                    throw new ArithmeticException("Não é possivel dividir por zero");
                }    
                resultado = primeiroNumero / segundoNumero;
                break;    
            default:
                resultado = segundoNumero; //Caso nenhum operador tenha sido escolhido
                break;
            
        }    
        
        return resultado;
        
    }        

    
    //Getters e Setters
    public double getPrimeiroNumero() {
        return primeiroNumero;
    }

    public void setPrimeiroNumero(double primeiroNumero) {
        this.primeiroNumero = primeiroNumero;
    }

    public double getSegundoNumero() {
        return segundoNumero;
    }

    public void setSegundoNumero(double segundoNumero) {
        this.segundoNumero = segundoNumero;
    }

    public String getOperacao() {
        return operacao;
    }

    public void setOperacao(String operacao) {
        this.operacao = operacao;
    }
    
    
    
}
