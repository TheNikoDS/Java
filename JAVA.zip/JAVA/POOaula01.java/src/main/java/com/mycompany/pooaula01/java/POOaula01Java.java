package com.mycompany.pooaula01.java;
public class POOaula01Java {

    public static void main(String[] args) {
        PEssoa p1 = new PEssoa();
        PEssoa p2 = new PEssoa();
        
        p1.nome = "João";
        p1.idade = 23;
        p1.email = "João123@gmail.com";
                
        p2.nome = "Helena";
        p2.idade = 24;
        p2.email = "Helena123@gmail.com";
                
        p1.falar();
        
    }
    }
