package com.mycompany.pooaula01.java;
package com.mycompany.pooaula01.java;
public class PEssoa {
    
    //***MOLDE***
    
    //Atributos
    private String nome;
    private int idade;
    
    private String email;
    
    //Encapsulamento
    public void setnome(String nome){
    this.nome = nome;
    }
    public String getnome(){
        return this.nome;
    }
    
    
    }
    //Método
    void falar(){
        System.out.println("Pessoa falando...");
        
    void andar(){
        System.out.println("Pessoa andando");
    }
    }
    
}
