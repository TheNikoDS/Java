
package com.mycompany.mavenproject2;
import java.util.Scanner;


public class Mavenproject2{
    

    public static void main(String[] args) {
        
    Scanner scanner = new Scanner(System.in);
    
    //criando objeto
    aluno aluno1 = new aluno();
    
    System.out.println("Digite o nome do Aluno");
    aluno1.setNome(scanner.nextLine());
    
    System.out.println("Digite a nota1");
    aluno1.setNota1(scanner.nextDouble());
    
    System.out.println("Digite a nota2");
    aluno1.setNota2(scanner.nextDouble());
    
    
    
    
    //atribuindo valores
    /*
    aluno1.setNome("Carlos");
    aluno1.setNota1(8.0);
    aluno1.setNota2(6.0);
   */
    //exibindo resultados
    System.out.println("Nome: " + aluno1.getNome());
    System.out.println("Nota1: " + aluno1.getNota1());
    System.out.println("Nota2: " + aluno1.getNota2());
    
    System.out.println("Média: " + aluno1.calcularMedia());
  }
}