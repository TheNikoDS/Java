
package com.mycompany.mavenproject2;


public class aluno {
    
    //atributos privados
    private String nome;
    private double nota1;
    private double nota2;
    
    //getters e setters
    public String getNome(){
        return nome;
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    public double getNota1(){
        return nota1;
    }
    public void setNota1(double nota1){
        this.nota1 = nota1;
    }
    public double getNota2(){
        return nota2;
    }
    public void setNota2(double nota2){
        this.nota2 = nota2;
    }
    //Caqlcular média
    public double calcularMedia() {
        return (nota1 + nota2) / 2;
    }
    
        //método para aprovação
    public String verificarSituacao() {
        if (calcularMedia() >= 7) {
            return "Aprovado";            
        } else {
            return "Reprovado";    
    }
  }
}