package com.mycompany.aula_heransa;
public class Aula_Heransa {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
