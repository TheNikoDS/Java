package main;
import java.util.Scanner;
public class ProjetoInterfaceVisual {

    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
    
    }
}
